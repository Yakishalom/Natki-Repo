import xbmc
import xbmcgui
import xbmcvfs
import os
import shutil
import traceback
import ctypes  # נדרש לקריסת התהליך בסוף

def log(msg):
    xbmc.log(f"[CopyToHome] {msg}", xbmc.LOGINFO)

def notify(title, message, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(title, message, icon, 5000)

def count_items_in_dir(directory):
    count = 0
    for root, dirs, files in os.walk(directory):
        count += len(files)
        count += len(dirs)
    return count

def copy_contents_with_progress(src_dir, dst_dir, progress, current_index, total_items):
    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)

    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        d = os.path.join(dst_dir, item)

        current_index[0] += 1
        percent = int((current_index[0] / total_items) * 100)
        progress.update(percent, f"מעתיק: {item}")

        if os.path.isdir(s):
            copy_contents_with_progress(s, d, progress, current_index, total_items)
        else:
            shutil.copy2(s, d)

def copy_inner_folders_to_kodi_home(source_package_folder):
    try:
        source_root = f"/storage/emulated/0/Download/{source_package_folder}"
        target_root = xbmcvfs.translatePath('special://home/')

        if not os.path.exists(source_root):
            notify("שגיאה", f"תיקיית מקור לא קיימת:\n{source_root}", error=True)
            return

        total_items = 0
        for folder in os.listdir(source_root):
            full_path = os.path.join(source_root, folder)
            if os.path.isdir(full_path):
                total_items += count_items_in_dir(full_path)

        if total_items == 0:
            notify("אין מה להעתיק", "התיקיות ריקות או לא נמצאו קבצים")
            return

        progress = xbmcgui.DialogProgress()
        progress.create("העתקת קבצים", "מתחיל בהעתקה...")

        current_index = [0]
        for folder in os.listdir(source_root):
            src_folder = os.path.join(source_root, folder)
            dst_folder = os.path.join(target_root, folder)

            if os.path.isdir(src_folder):
                copy_contents_with_progress(src_folder, dst_folder, progress, current_index, total_items)

        progress.close()
        notify("הצלחה", f"תוכן {source_package_folder} הועתק ל־Kodi")

        xbmcgui.Dialog().ok("התקנה הושלמה", "Kodi ייסגר כעת. יש להפעילו מחדש ידנית.")

        # 💥 סגירה מוחלטת: קריסת התהליך כדי שהמשימה תוסר גם מה־background
        ctypes.string_at(0)

    except Exception as e:
        error_msg = traceback.format_exc()
        log("שגיאה:\n" + error_msg)
        notify("שגיאה", str(e), error=True)

copy_inner_folders_to_kodi_home("install_package")
